import React, { useEffect, useState } from "react";
import { StyleSheet } from "react-native";
import {
  ViroAnimations,
  ViroARImageMarker,
  ViroARTrackingTargets,
  ViroFlexView,
  ViroImage,
  ViroNode,
  ViroSound,
  ViroVideo,
} from "react-viro";

const ImgMarker = ({
  id,
  targetImage,
  image,
  video,
  imageLink,
  button1,
  button2,
  button3,
}) => {
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    ViroARTrackingTargets.createTargets({
      [id]: {
        source: { uri: targetImage },
        orientation: "Up",
        physicalWidth: 0.05,
      },
    });
    setLoaded(true);
  }, []);
  return (
    loaded && (
      <ViroNode>
        {loaded && (
          <ViroARImageMarker target={id}>
            <ViroSound source={require("../res/sound.mp3")} />
            <ViroNode key='card'>
              <ViroNode position={[0, -0.01, -0.026]}>
                <ViroFlexView
                  rotation={[-90, 0, 0]}
                  style={styles.card}
                  style={styles.buttonGroup}
                >
                  <ViroImage
                    style={styles.button}
                    onClick={() => {
                      alert(button1);
                    }}
                    source={require("../res/button1.png")}
                  />
                  <ViroImage
                    style={styles.button}
                    onClick={() => {
                      alert(button2);
                    }}
                    source={require("../res/button2.png")}
                  />
                  <ViroImage
                    style={styles.button}
                    onClick={() => {
                      alert(button3);
                    }}
                    source={require("../res/button3.png")}
                  />
                </ViroFlexView>
              </ViroNode>
              <ViroNode position={[0.058, 0, -0.008]} rotation={[-90, 0, 0]}>
                <ViroImage
                  source={{ uri: image }}
                  height={0.046}
                  width={0.06}
                />
              </ViroNode>
              <ViroNode position={[0, 0, 0]} rotation={[-90, 0, 0]}>
                <ViroVideo
                  source={{
                    uri: video,
                  }}
                  width={0.05}
                  height={0.03}
                  loop={true}
                />
              </ViroNode>
            </ViroNode>
          </ViroARImageMarker>
        )}
      </ViroNode>
    )
  );
};

ViroAnimations.registerAnimations({
  amRight: {
    properties: {
      positionX: 0.04,
      opacity: 1.0,
    },
    easing: "Bounce",
    duration: 2000,
  },
  amBottom: {
    properties: {
      positionZ: 0.034,
      opacity: 1,
    },
    easing: "Bounce",
    duration: 2000,
  },
});

const styles = StyleSheet.create({
  buttonGroup: {
    display: "flex",
    flexDirection: "row",
    width: 0.052,
    justifyContent: "space-between",
    // backgroundColor: "#fff",
  },
  button: {
    width: 0.012,
    height: 0.012,
  },
  textStyle: {
    flex: 0.5,
    fontFamily: "Roboto",
    fontSize: 30,
    color: "#ffffff",
    textAlignVertical: "top",
    textAlign: "left",
    fontWeight: "bold",
  },
});

export default ImgMarker;
