import React, { Component } from "react";
import { ViroARScene } from "react-viro";
import ImgMarker from "./ImgMarker";
const axios = require("axios");

export default class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      profiles: [],
      loaded: false,
    };
  }

  getMediaLink(id, fileName) {
    return fileName ? `http://13.68.187.88:5000/files/${id}/${fileName}` : null;
  }

  componentDidMount() {
    axios.get("http://13.68.187.88:5000/documents").then(({ data }) => {
      this.setState({ ...this.state, profiles: data, loaded: true });
    });
  }

  render() {
    const { profiles, loaded } = this.state;
    return (
      <ViroARScene>
        {loaded &&
          profiles.map(pr => {
            alert(JSON.stringify(pr.targetImage));
            const {
              _id,
              targetImage,
              image,
              video,
              imageLink,
              button1,
              button2,
              button3,
            } = pr;
            alert(this.getMediaLink(_id, targetImage));
            return (
              <ImgMarker
                key={_id}
                id={_id}
                userId={_id}
                targetImage={this.getMediaLink(_id, targetImage)}
                image={this.getMediaLink(_id, image)}
                video={this.getMediaLink(_id, video)}
                button1={button1}
                button2={button2}
                button3={button3}
                imageLink={imageLink}
              />
            );
          })}
      </ViroARScene>
    );
  }
}
