import React from "react";
import { ViroARSceneNavigator } from "react-viro";
import Main from "./src/components/Main";
const App = () => {
  return (
    <ViroARSceneNavigator
      initialScene={{ scene: Main }}
      autofocus={true}
      bloomEnabled={true}
      hdrEnabled={true}
      shadowsEnabled={true}
    />
  );
};

export default App;
