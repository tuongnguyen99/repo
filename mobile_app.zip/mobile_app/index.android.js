import { AppRegistry } from 'react-native';
import App from './App.js';

AppRegistry.registerComponent('APP_NAME_HERE', () => App);

// The below line is necessary for use with the TestBed App
AppRegistry.registerComponent('ViroSample', () => App);